from os import remove
import sched
from covid_dashboard.__main__ import add_update
from covid_dashboard.__main__ import update_time
from covid_dashboard.__main__ import update_submit
from covid_dashboard.__main__ import remove_article
from covid_dashboard.__main__ import update_covid_data
from covid_dashboard.__main__ import remove_update, updates_list
from covid_dashboard.covid_news_handling import config_data, s_news
from covid_dashboard.covid_data_handler import sched_updates, schedule_covid_updates, s_data

def test_add_update():
    add_update('test_update', '11:00', 'covid', None, None)
    assert updates_list[0]['title'] == 'test_update'

def test_update_time():
    test_time = update_time('12:45')
    assert (isinstance(test_time, int)) == True

# def test_update_submit():
#     update_submit('covid', None, '12:30', 'test', None)

def test_remove_article():
    remove_article('test_article_title')
    assert config_data['removed_articles'][0] == 'test_article_title'

def test_update_covid_data():
    update_covid_data()

def test_remove_update():
    sched_updates.clear()
    schedule_covid_updates(100, 'test_update', 'news', None)
    remove_update('test_update')
    assert len(sched_updates) == 0
    assert len(s_news.queue) == 0
    