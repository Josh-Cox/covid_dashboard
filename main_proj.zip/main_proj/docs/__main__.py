from flask import Flask, render_template, redirect, url_for

app = Flask(__name__, template_folder='build/html')

@app.route('/')
def redirect_home():
    """Redirect To Index Page"""
    return redirect(url_for('home'))

@app.route('/index.html')
def home():
    return(render_template('index.html'))

@app.route('/modules.html')
def covid_dashboard():
    return(render_template('modules.html'))

@app.route('/covid_dashboard.html')
def covid_dashboard_package():
    return(render_template('covid_dashboard.html'))

@app.route('/genindex.html')
def index():
    return(render_template('genindex.html'))

@app.route('/py-modindex.html')
def module_index():
    return(render_template('py-modindex.html'))

@app.route('/search.html')
def search():
    return(render_template('search.html'))

if __name__ == '__main__':
    app.run()