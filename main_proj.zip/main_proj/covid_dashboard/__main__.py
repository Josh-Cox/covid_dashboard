"""MAIN MODULE"""
from datetime import datetime
from os import path, getcwd
from flask import Flask, redirect, url_for, render_template, request
from .covid_data_handler import (schedule_covid_updates,
s_data,
sched_updates,
get_data)
from .covid_news_handling import (config_data,
s_news,
update_news,
news_list,
enter_log,
schedule_news_updates)

#---------- Define Variables ----------#
app = Flask(__name__, template_folder=path.join(getcwd(), 'templates'))

#Update Notices
updates_list = []

def add_update(update_name, update_time, covid, news, repeat):
    """Add Update"""

    if covid and news:
        display_data = 'BOTH'
    elif covid:
        display_data = 'DATA'
    elif news:
        display_data = 'NEWS'
    if repeat:
        display_repeat = 'YES'
    else:
        display_repeat = 'NO'
    
    updates_list.append({
        'title': update_name,
        'content': f'Time of Update: {update_time} | Updates: {display_data} | Repeat: {display_repeat}'
    })

def update_time(time_of_update):
    """Return Update Time Interval"""

    #Find the times in hours and minutes
    now = datetime.now()
    current_time = now.strftime("%H:%M")
    c_hours, c_mins = current_time.split(':')
    w_hours, w_mins = time_of_update.split(':')
    #Find the absolute difference
    diff_hours = abs(int(c_hours) - int(w_hours))
    diff_mins = abs(int(c_mins) - int(w_mins))
    #Convert to seconds
    interval = (diff_hours*60*60) + (diff_mins * 60)
    return interval

def update_submit(covid, news, u_time, text, repeat):
    """Check Updates"""
    #Log Update Submit
    enter_log('[INFO]', 'USER UPDATE SUBMITTED')
    #Determine which data should be updated
    if covid and news:
        add_update(text, u_time, covid, news, repeat)
        schedule_covid_updates(update_time(u_time), text, 'both', repeat)
    elif covid:
        add_update(text, u_time, covid, news, repeat)
        schedule_covid_updates(update_time(u_time), text, 'covid', repeat)
    else:
        add_update(text, u_time, covid, news, repeat)
        schedule_news_updates(update_time(u_time), text, 'news', repeat)

def remove_article(article_title):
    """Remove News Article"""
    #Append removed_articles list
    config_data['removed_articles'].append(article_title)
    #Log Article Removal
    enter_log('[INFO]', f'ARTICLE REMOVED - ({article_title})')
    #Refresh news articles
    update_news()

def update_covid_data(name=None, u_type=None, repeat=None):
    """Update All Covid Data"""
    #Define global variables
    global local_case_7_days
    global national_case_7_days
    global local_area_name
    global national_hospital_cases
    global national_total_deaths
    global national_area_name
    #Set variables
    (
        national_hospital_cases,
        national_total_deaths,
        national_area_name,
        national_case_7_days,
        local_area_name,
        local_case_7_days
    ) = get_data()
    #Repeat if necessary
    if repeat:
        schedule_covid_updates(10, name, u_type, repeat)

def remove_update(update_name):
    """Remove Update From Scheduler"""
    #Find update by title and remove from scheduler
    index = 0
    for item in sched_updates:
        if item['title'] == update_name:
            if item['type'] == 'covid':
                if item['event'] in s_data.queue:
                    s_data.cancel(item['event'])
            elif item['type'] == 'news':
                if item['event'] in s_news.queue:
                    s_news.cancel(item['event'])
            elif item['type'] == 'both':
                if item['event'] in s_data.queue:
                    s_data.cancel(item['event'])
                for i in sched_updates:
                    if i['title'] == f'n{update_name}':
                        if item['event'] in s_news.queue:
                            s_news.cancel(item['event'])
            sched_updates.remove(item)
    #Find update by title and remove from updates_list
    while index < len(updates_list):
        if updates_list[index]['title'] == update_name:
            del updates_list[index]
        else:
            index += 1

    #Log Update Removal
    enter_log('[INFO]', f'UPDATE REMOVED - ({update_name})')

#---------- Flask Routes ----------#

#Redirect to Index Page
@app.route('/')
def redirect_home():
    """Redirect To Index Page"""
    return redirect(url_for('home'))

#Index Page
@app.route('/index')
def home():
    """Index Page Load"""

    s_data.run(blocking=False)
    s_news.run(blocking=False)

    #Get Variables
    text_field = request.args.get('two')
    covid_update = request.args.get('covid-data')
    news_update = request.args.get('news')
    time_of_update = request.args.get('update')
    update_repeat = request.args.get('repeat')

    if text_field:
        update_submit(covid_update, news_update, time_of_update, text_field, update_repeat)

    #Update or Article Deleted
    article_deleted = request.args.get('notif')
    update_deleted = request.args.get('update_item')

    if update_deleted:
        remove_update(update_deleted)
    if article_deleted:
        remove_article(article_deleted)
    else:
        pass

    #Log Refresh
    enter_log('[INFO]', 'PAGE REFRESHED')

    #Return values
    return render_template('index.html',
    title='Covid News',
    deaths_total = f'National Cumulative Deaths: {national_total_deaths}',
    hospital_cases = f'National Hospital Cases: {national_hospital_cases}',
    news_articles = news_list,
    updates = updates_list,
    location = local_area_name,
    local_7day_infections = local_case_7_days,
    nation_location = national_area_name,
    national_7day_infections = national_case_7_days,
    image = 'covid_image.png',
    favicon = 'https://freesvg.org/img/1586348910virus.png')


if __name__ == '__main__':
    update_covid_data()
    update_news()
    app.run()
