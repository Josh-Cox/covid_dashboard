.. Covid Dashboard documentation master file, created by
   sphinx-quickstart on Wed Dec 15 14:47:49 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Covid Dashboard's documentation!
===========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
