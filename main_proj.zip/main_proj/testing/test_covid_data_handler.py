from covid_dashboard.covid_data_handler import parse_csv_data
from covid_dashboard.covid_data_handler import process_covid_csv_data
from covid_dashboard.covid_data_handler import covid_API_request
from covid_dashboard.covid_data_handler import find_value
from covid_dashboard.covid_data_handler import infection_7_days
from covid_dashboard.covid_data_handler import schedule_covid_updates, s_data

def test_parse_csv_data():
    data = parse_csv_data('nation_2021-10-28.csv')
    assert len(data) == 639

def test_process_covid_csv_data():
    last7days_cases , current_hospital_cases , total_deaths = \
        process_covid_csv_data ( parse_csv_data (
            'nation_2021-10-28.csv' ) )
    assert last7days_cases == 240_299
    assert current_hospital_cases == 7_019
    assert total_deaths == 141_544

def test_covid_API_request():
    data = covid_API_request()
    assert isinstance(data, dict)

def test_schedule_covid_updates():
    schedule_covid_updates(update_interval=10, update_name='update test')
    
def test_infection_7_days():
    test_data = {'data': [
        {
            'area_code': 'E07000041',
            'area_name': 'Exeter',
            'area_type': 'ltla',
            'date': '2020-03-03',
            'cum_deaths': 134,
            'hospital_cases': 703,
            'new_cases_by_specimen': None
        },
        {
            'area_code': 'E07000041',
            'area_name': 'Exeter',
            'area_type': 'ltla',
            'date': '2020-03-02',
            'cum_deaths': 116,
            'hospital_cases': 645,
            'new_cases_by_specimen': 36
        },
        {
            'area_code': 'E07000041',
            'area_name': 'Exeter',
            'area_type': 'ltla',
            'date': '2020-03-01',
            'cum_deaths': 100,
            'hospital_cases': 500,
            'new_cases_by_specimen': 48
        },
                {
            'area_code': 'E07000041',
            'area_name': 'Exeter',
            'area_type': 'ltla',
            'date': '2020-03-03',
            'cum_deaths': 134,
            'hospital_cases': 703,
            'new_cases_by_specimen': 55
        },
        {
            'area_code': 'E07000041',
            'area_name': 'Exeter',
            'area_type': 'ltla',
            'date': '2020-03-02',
            'cum_deaths': 116,
            'hospital_cases': 645,
            'new_cases_by_specimen': 63
        },
        {
            'area_code': 'E07000041',
            'area_name': 'Exeter',
            'area_type': 'ltla',
            'date': '2020-03-01',
            'cum_deaths': 100,
            'hospital_cases': 500,
            'new_cases_by_specimen': 51
        },
        {
            'area_code': 'E07000041',
            'area_name': 'Exeter',
            'area_type': 'ltla',
            'date': '2020-03-01',
            'cum_deaths': 100,
            'hospital_cases': 500,
            'new_cases_by_specimen': 45
        },
        {
            'area_code': 'E07000041',
            'area_name': 'Exeter',
            'area_type': 'ltla',
            'date': '2020-03-01',
            'cum_deaths': 100,
            'hospital_cases': 500,
            'new_cases_by_specimen': 32
        },
        {
            'area_code': 'E07000041',
            'area_name': 'Exeter',
            'area_type': 'ltla',
            'date': '2020-03-01',
            'cum_deaths': 100,
            'hospital_cases': 500,
            'new_cases_by_specimen': 34
        }
    ]}

    assert infection_7_days(test_data) == 328

def test_find_value():
    test_data = {'data': [
        {
            'area_code': 'E07000041',
            'area_name': 'Exeter',
            'area_type': 'ltla',
            'date': '2020-03-03',
            'cum_deaths': 134,
            'hospital_cases': None,
            'new_cases_by_specimen': None
        },
        {
            'area_code': 'E07000041',
            'area_name': 'Exeter',
            'area_type': 'ltla',
            'date': '2020-03-02',
            'cum_deaths': 116,
            'hospital_cases': 645,
            'new_cases_by_specimen': 36
        }
    ]}
    
    assert find_value('hospital_cases', test_data) == 645
