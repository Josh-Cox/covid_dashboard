covid\_dashboard package
========================

Submodules
----------

covid\_dashboard.covid\_data\_handler module
--------------------------------------------

.. automodule:: covid_dashboard.covid_data_handler
   :members:
   :undoc-members:
   :show-inheritance:

covid\_dashboard.covid\_news\_handling module
---------------------------------------------

.. automodule:: covid_dashboard.covid_news_handling
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: covid_dashboard
   :members:
   :undoc-members:
   :show-inheritance:
